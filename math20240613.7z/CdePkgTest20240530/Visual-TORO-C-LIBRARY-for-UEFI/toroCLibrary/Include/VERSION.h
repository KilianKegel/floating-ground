#define MAJORVER 0
#define MINORVER 8
#define PATCHVER 4
#define YEARSTART 2017
#define YEARCURRENT 2024
