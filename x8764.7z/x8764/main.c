#include <stdio.h>
#include <stdlib.h>
#include <math.h>

extern double __cdecl torosin(double _X);

int main(int argc, char** argv)
{
	double d = 9223372036854775808000012345678.0;// (2 * (9223372036854775808LL - 1000LL));
	//__debugbreak();
	d = torosin(d);

	printf("%.32f\n", d);

}
