#include <stdio.h>
#include <stdlib.h>
#include <math.h>

extern double __cdecl torosqrt(double _X);

int main(int argc, char** argv)
{
	double d = -92.0;

	d = torosqrt(d);

	printf("%f, %llX\n", d,d);

}
