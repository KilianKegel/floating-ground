#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>

extern double __cdecl toroatan(double _X);

int main(int argc, char** argv)
{
	double d = 3.0;
	uint64_t* pd = (void*) &d;

	d = toroatan(d);

	printf("%f, %llX\n", d,*pd);

}
